package com.experion.mainbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainbackendApplication.class, args);
	}
}
